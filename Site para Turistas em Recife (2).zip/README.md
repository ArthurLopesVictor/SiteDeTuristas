
  # Site para Turistas em Recife

  This is a code bundle for Site para Turistas em Recife. The original project is available at https://www.figma.com/design/UHGge1Sly5qyuVxXYaFPel/Site-para-Turistas-em-Recife.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  